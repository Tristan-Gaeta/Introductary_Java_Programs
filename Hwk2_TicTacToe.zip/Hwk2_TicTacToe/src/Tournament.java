/**
 * This class contains a method playGame that is given two players and
 * plays a game of tic-tac-toe between the two, returning the winner,
 * null if it is a tie.
 *
 * @author Tristan Gaeta
 * @version 9-20-2020
 */
public class Tournament {

    /**
     * playGame is passed two player objects, assigns their symbols
     * X and O, then plays a game of tic-tac-toe between the two
     * players. It then returns the winning Player, null if they tied.
     *
     * @param p1 the first player, X.
     *
     * @param p2 the second player, O.
     *
     * @return the winning player, null if tied.
     */
    public static Player playGame(Player p1, Player p2){
        Board b = new Board();
        p1.setSymbol(Board.X); //to prevent errors with the board
        p2.setSymbol(Board.O);

        do {
            p1.makeMove(b);
            p2.makeMove(b);
        }while (!b.boardFilled()&&(b.getWinner() == -1));

        int winner = b.getWinner();

        if(winner != -1){ //if not a tie
            Player w =  (winner == Board.X)? p1: p2;
            Player l = (p1 == w)?p2: p1;
            System.out.println(w.celebrate());
            System.out.println(l.mourn());
            return w;
        }
        else{
            return null;
        }
    }
}
