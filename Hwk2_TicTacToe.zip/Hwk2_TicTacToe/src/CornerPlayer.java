/**
 * CornerPlayer class extends the RandomPlayer class and models models a Tic-Tac-Toe player
 * that fills in the corners before filling the rest of the spots randomly.  When created, instances
 * of this class are told whether they're playing X or O, and given an identifying string.
 * The makeMove() method loops through the corners of the board, moving there if any are open,
 * else picking randomly from the open spots.
 *
 *
 * @author Tristan Gaeta
 * @version 9-20-2020
 */
public class CornerPlayer extends RandomPlayer{
    /**
     * The constructor takes a constant from the Board class describing
     * whether this player is X or O (Board.X or Board.O), and the
     * player's name and calls the super constructor.
     *
     * @param symbol  One of the player constants from the Board class
     *                (Board.X or Board.O).
     * @param name  The player's name.
     */
    public CornerPlayer(int symbol, String name){
        super(symbol, name);
    }

    /**
     * makeMove is passed a game board, and modifies the board to reflect
     * the player's next move. The players next move is determined by looping
     * through the corners of the board and moving there if any are open. If no
     * corners are open the makeMove method of the superclass is called,
     * generating a random move.
     *
     * @param theBoard  The board on which we're to make a move.
     */
    @Override
    public void makeMove(Board theBoard) {
        if(theBoard.boardFilled()){
            return;
        }
        for(int i = 0; i < 3; i +=2){
            for(int j = 0; j < 3; j +=2){
                if(theBoard.isOpen(i,j)){
                    theBoard.fillPosition(i,j,symbol);
                    return;
                }
            }
        }
        super.makeMove(theBoard);
    }
}
