/**
 *  RandomPlayer class extends the Player class and models models a Tic-Tac-Toe player that
 *  chooses random spots on the board until an open spot is found.  When created, instances
 *  of this class are told whether they're playing X or O, and given an identifying string.
 *  The makeMove() method generates random column and row indices until the randomly generated
 *  spot is open, then places a character in that spot.
 *
 * @author Tristan Gaeta
 * @version 9-20-2020
 */
public class RandomPlayer extends Player{
    /**
     * The constructor takes a constant from the Board class describing
     * whether this player is X or O (Board.X or Board.O), and the
     * player's name and calls the super constructor.
     *
     * @param symbol  One of the player constants from the Board class
     *                (Board.X or Board.O).
     * @param name  The player's name.
     */
    public RandomPlayer(int symbol, String name){
        super(symbol, name);
    }

    /**
     * makeMove is passed a game board, and modifies the board to reflect
     * the player's next move. The players next move is determined by generating
     * random column and row indices until the randomly generated spot is open.
     *
     * @param theBoard  The board on which we're to make a move.
     */
    @Override
    public void makeMove(Board theBoard) {
        if(theBoard.boardFilled()){
            return;
        }
        int col, row;
        do{
            col = (int)(Math.random()*3);
            row = (int)(Math.random()*3);
        }while (!theBoard.isOpen(col,row));
        theBoard.fillPosition(col,row,symbol);
    }
}
