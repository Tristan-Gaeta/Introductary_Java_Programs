/**
 * Tristan_Gaeta_Player extends the Player class and models a Tic-Tac-Toe player that will never lose!
 * When created, instances of this class are told whether they're playing X or O, and given an
 * identifying string. The technique we use to determine the player's best move is known as a MiniMax
 * algorithm; we analyze each open spot by computing all of the possible outcomes of the game if we
 * were to move to that spot. Since tic-tac-toe only has three possible outcomes, win, lose, or tie,
 * we can represent these outcomes as +1, -1, and 0, respectively. We assume that the opponent player
 * will play optimally, (i.e. try to win,) so we will return the lowest possible outcome (hence the mini-max).
 * So if a given board can in any way result in a loss it is assigned a minimax value of -1. If the player
 * could either win or tie the minimax value would be 0. A minimax value of 1 is only assigned if the only
 * possible outcome is victory. We choose the open spot with the highest minimax value as the spot to play.
 *
 * @author Tristan Gaeta
 * @version 9-20-2020
 */
public class Tristan_Gaeta_Player extends Player{
    private final int opponent; //what is the opponent's symbol? we'll reference it quite a bit

    /**
     * The constructor takes a constant from the Board class describing
     * whether this player is X or O (Board.X or Board.O), and the
     * player's name and calls the super constructor. The opponent's
     * symbol is then determined by this player's symbol (Board.X or Board.O).
     *
     * @param symbol  One of the player constants from the Board class
     *                (Board.X or Board.O).
     * @param name  The player's name.
     */
    public Tristan_Gaeta_Player(int symbol, String name) {
        super(symbol, name);
        this.opponent = (symbol == Board.X) ? Board.O : Board.X; //if we're X, they must be O and vice versa
    }

    /**
     * copyBoard is passed a game board, creates a new game board to return,
     * then loops through the original board and copies its contents to the new
     * game board. This method is used to so we don't alter the actual game board
     * when moving pieces to analyze our potential moves. It creates a copy of the
     * original board that we can manipulate however we'd like without altering the
     * game.
     *
     * @param original  The original board to be copied.
     *
     * @return The new copy of the board.
     */
    public Board copyBoard(Board original){
        Board outBoard = new Board();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int sym = original.getContents(i, j);
                if (sym != Board.BLANK) {
                    outBoard.fillPosition(i, j, sym);
                }
            }
        }
        return outBoard;
    }

    /**
     * makeMove is passed a game board, and modifies the board to reflect
     * the player's next move. The players next move is determined by looping
     * through the board and determining which open spot has the highest minimax
     * value determined by <code>minimax</code>. We do this by creating a copy of
     * the board for each open spot and moving to that spot to analyze the
     * potential outcomes. We then move to the spot with the highest minimax value.
     *
     * @param realBoard  The board on which we're to make a move.
     */
    @Override
    public void makeMove(Board realBoard) {
        if (realBoard.boardFilled()) {
            return;
        }
        Board testBoard = this.copyBoard(realBoard);
        int[] move = null;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (testBoard.isOpen(i, j)) {
                    testBoard.fillPosition(i, j, this.symbol);
                    int score = this.minimax(testBoard, this.opponent);
                    if (score > max) {
                        max = score;
                        move = new int[]{i, j};
                    }
                    testBoard = this.copyBoard(realBoard);
                }
            }
        }
        realBoard.fillPosition(move[0], move[1], this.symbol);
    }

    /**
     * This is a recursive function used to analyze all of the potential outcomes
     * of the board in it's current state. The minimax method is passed a game
     * board, a copy or variant of the original game board, and the current player's
     * symbol (Board.X or Board.O). This function calls itself, trying every potential
     * move combination from the original board, until the theoretical game is over
     * then passes back the lowest possible score --where +1, -1, and 0 correspond to
     * win, loss, and draw.
     *
     * @param inBoard the board to be further analyzed
     *
     * @param player the symbol of the player whose turn it is next from the board
     *
     * @return the minimax value of the board in it's original state; -1 if loss is
     */
    public int minimax(Board inBoard, int player) {
        int winner = inBoard.getWinner();
        int score;
        if (winner != -1) {
            score = (winner == this.symbol) ?1 :-1;
            return score;
        } else if (inBoard.boardFilled()) {
            return 0;
        }
        int nextPlayer = (player == this.symbol) ? this.opponent : this.symbol;
        int minimax = (player == this.symbol) ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        Board testBoard = this.copyBoard(inBoard);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (testBoard.isOpen(i, j)) {
                    testBoard.fillPosition(i, j, player);
                    score = minimax(testBoard, nextPlayer);
                    testBoard = this.copyBoard(inBoard);
                    if (player == this.symbol) {
                        minimax = Math.max(score, minimax);
                    } else {
                        minimax = Math.min(score, minimax);
                    }
                }
            }
        }
        return minimax;
    }
}
