/**
 * This class is simply used for testing and debugging. Please See other classes
 * for more details about the code. The main method runs through a game with
 * the bot.
 */

public class Main {

    public static void botContest(Player b1, Player b2){
        Board b = new Board();
        Player bot1 = b1;
        Player bot2 = b2;
        int bot1_wins = 0;
        int bot2_wins = 0;
        int ties = 0;

        for (int i = 0; i < 1000; i++) {
            do {
                bot1.makeMove(b);
                System.out.println(b.toString());
                bot2.makeMove(b);
                System.out.println(b.toString());
            }while (!b.boardFilled()&&(b.getWinner() == -1));
            if(b.getWinner() != -1){
                if(b.getWinner() == Board.X){
                    bot1_wins++;
                }
                else{
                    bot2_wins++;
                }
            }
            else{
                ties++;
            }

        }
        System.out.println("bot 1 wins:"+bot1_wins);
        System.out.println("bot 2 wins:"+bot2_wins);
        System.out.println("ties:"+ties);
    }

    public static void playBot(){
        Board b = new Board();
        Player me = new Player(Board.X,"Tristan");
        Player bot2 = new Tristan_Gaeta_Player(Board.O,"Bot 2");
        do {
            me.makeMove(b);
            System.out.println(b.toString());
            bot2.makeMove(b);
        }while (!b.boardFilled()&&(b.getWinner() == -1));
        System.out.println(b.toString());
    }
    public static void main(String[] args) {
        //botContest(new Tristan_Gaeta_Player(Board.X,"bot1"), new Tristan_Gaeta_Player(Board.O,"bot2"));
        playBot();
        //Player w = Tournament.playGame(new Tristan_Gaeta_Player(Board.X,"bot1"), new Tristan_Gaeta_Player(Board.O,"bot2"));

    }
}