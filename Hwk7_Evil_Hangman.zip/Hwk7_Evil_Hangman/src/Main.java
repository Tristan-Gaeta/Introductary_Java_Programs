/**
 * This class contains the main method which runs the game loop.
 *
 * @author Tristan Gaeta
 * @version 12-04-2020
 */
import java.util.*;
public class Main{

    public static void main(String[] args){
        //set up game settings
        Scanner scanner = new Scanner(System.in);
        System.out.println("- - - Hangman - - -");
        //prompt user for word length
        int size = 0;
        while(size <= 0 || size > EvilPlayer.LARGEST_WORD_LENGTH){
            System.out.print("\nHow long should the word be? ");

            try{
                size = Integer.parseInt(scanner.next());
            }catch(Exception e){
                size = 0;
            }
            if(size <= 0 || size > EvilPlayer.LARGEST_WORD_LENGTH){
                System.out.println("\nA word of length "+size+"? That won't work!");
            }
        }
        //prompt user for number of attempts
        int attempts = 0;
        while(attempts < 1){
            System.out.print("\nHow many tries do you need? ");
            try{
                attempts = Integer.parseInt(scanner.next());
            }catch(Exception e){
                attempts = 0;
            }
            if(attempts < 1){
                System.out.println("\n"+attempts+" attempts? That won't work!");
            }
        }
        //prompt user for printing out possible words
        boolean printWords;
        while(true){
            System.out.print("\nWould you like to print out your word options? ('Yes' or 'No') ");
            String askQ = scanner.next();
            if(askQ.equalsIgnoreCase("yes")){
                printWords = true;
                break;
            }else if(askQ.equalsIgnoreCase("no")){
                printWords = false;
                break;
            }else{
                System.out.println("Sorry, try again.");
            }
        }

        EvilPlayer bot = new EvilPlayer(size,attempts,printWords);//create our 'hangman' with the desired settings

        //begin game loop
        while(true){
            bot.printGame();
            System.out.print("Guess a letter: ");
            char guess;
            String input = scanner.next().toUpperCase();
            guess = input.charAt(0);
            if((guess < 'A' || guess > 'Z') || input.length() != 1){
                System.out.println("That's not even a letter!");
            }else{
                bot.checkGuess(guess);
                int result = bot.playerStatus();
                if(result != 0){
                    while(true){
                        System.out.print("Do you want to play again? ('Yes' or 'No' ) ");
                        String answer = scanner.next();
                        if(answer.equalsIgnoreCase("yes")){
                            Main.main(args);
                        }
                        else if(answer.equalsIgnoreCase("no")){
                            System.out.println("\nThanks for playing.");
                            break;
                        }
                        else{
                            System.out.println("Ahem...");
                        }
                    }
                    break;
                }
            }
        }
    }
}

