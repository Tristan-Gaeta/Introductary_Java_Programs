/**
 * This class represents the word on the board of a game of Hangman.
 * letters are only revealed when the player guesses them correctly, so
 * this extension of the Word class gives us a method to to that.
 *
 * @author Tristan Gaeta
 * @version 12-04-2020
 */

import java.util.Set;
public class EvilWord extends Word{

    /*
     * THis constructor creates an EvilWord object of the specified
     * length with no letters yet revealed
     */
    public EvilWord(int wordLength){
        super("");
        for(int i = 0; i < wordLength; i++){
            this.word += "_";
        }
    }

    /*
     * This method reveals the input indices with the given primitive character
     */
    public String reveal(Set<Integer> indxs, char rep){
        char[] chars = this.word.toCharArray();
        for (Integer indx : indxs) {
            chars[indx] = rep;
        }
        this.word = new String(chars);
        return this.word;
    }
}