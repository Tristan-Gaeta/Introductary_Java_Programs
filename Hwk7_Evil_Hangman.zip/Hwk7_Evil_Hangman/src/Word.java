/**
 * Objects of this class are used to represent any word for a game
 * of Hangman. Word objects contain a String representation of the word
 * and a method that takes a primitive character type as input and returns
 * a set containing the indices where that character occurs in the word.
 * This is used to group words with similar structures together.
 *
 * @author Tristan Gaeta
 * @version 12-04-2020
 *
 */

import java.util.*;
public class Word{
    public String word; //String representation of the word

    /*
     * This constructor takes as input the String representation of the word.
     */
    public Word(String s){
        this.word = s;
    }

    /*
     * This method takes as input a primitive char type and returns
     * a TreeSet of integers containing the indices where that character
     * occurs in the String representation of the word.
     */
    public Set<Integer> getFormat(char target){
        TreeSet<Integer> out = new TreeSet<>(); //the set to be returned
        //cycle through the word iteratively to get indices of char
        for(int i = 0; i < this.word.length(); i++){
            char c = this.word.charAt(i);
            if(c == target){
                out.add(i);
            }
        }
        return out;
    }

    /*
     * String representations of Word objects are simply the word itself
     */
    @Override
    public String toString(){
        return this.word;
    }
}