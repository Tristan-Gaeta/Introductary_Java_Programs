/**
 * This class is where the 'cheating' happens in our game of hangman.
 * An EvilPlayer object keeps track of our game settings as well as
 * all of the possible words that fit our letter guesses.  When a
 * letter is guessed, the word set is divided into subsets of differing
 * structures, then the largest subset is chosen as our new word format.
 * This will maximize the number of guesses we have to make until we
 * reveal the word. This division of the set occurs until there is only
 * one option left.
 *
 * @author TRistan Gaeta
 * @version 12-04-2020
 *
 */

import java.util.*;
import java.io.*;
public class EvilPlayer {

    public static final int LARGEST_WORD_LENGTH = 29;//length of longest word in our dictionary
    private List<Character> attempts;//letters attempted.
    private int triesLeft; //remaining attempts
    private Word word; //the word on our game board
    private WordSet wordSet; //the remaining words that fit our word structure
    private boolean printWords; //the option print all of the possible words; for debugging

    /*
     * This constructor initializes our variables and generates the
     * initial word set, containing all words of the specified length
     */
    public EvilPlayer(int wordLength, int tries, boolean printWords){
        //game settings
        this.printWords = printWords;
        this.triesLeft = tries;
        this.word = new EvilWord(wordLength);
        //generate initial word set
        this.attempts = new LinkedList<>();
        this.wordSet = new WordSet();
        this.readFile(wordLength);
    }
    /*
     * This method generates out initial word set. Reading our source file,
     * every word of the specified length is added to the word set.
     */
    private void readFile(int wordLength){
        System.out.println("Just a second...");
        //initialize scanner
        Scanner scan;
        try{
            scan = new Scanner(new File("dictionary.txt"));

        }catch(FileNotFoundException e){
            System.out.println("File not found");
            this.triesLeft = 0; //to exit game loop
            return;
        }
        //read file
        while(scan.hasNextLine()){
            String toAdd = scan.nextLine().toUpperCase(); //All letters are capital to reduce chance of error
            if (toAdd.length() == wordLength){
                this.wordSet.add(new Word(toAdd));
            }
        }
        scan.close();
    }

    /*
     * Prints out the current game board
     */
    public void printGame(){
        if(this.printWords){ //printing remaining word set is optional
            System.out.println("\n"+this.wordSet);
        }

        System.out.println("\nCurrent Word: "+this.word); //currents state of word being guessed
        System.out.println("Letters used: "+this.attempts);
        System.out.println("You have "+this.triesLeft+" more guesses.");
    }

    /*
     * This method is called when the player guesses a letter. We reduce our
     * word set to the largest of the subsets, and if that subset contains the
     * letter that was guessed, we reveal it in our word. Else we deduct an
     * attempt from the player.
     */
    public void checkGuess(char guess){
        //check to see if the letter has already been guessed
        if(this.attempts.contains(guess)){
            System.out.println("You already guessed that letter.");
            return;
        }
        //reduce word options
        Set<Integer> wordGroup = this.wordSet.reduceSet(guess);

        this.attempts.add(guess);
        if(wordGroup.isEmpty()){ //if the word structure does not contain the guessed letter
            this.triesLeft--;
            System.out.println("Nope!");
        }else{
            ((EvilWord) this.word).reveal(wordGroup, guess);
            System.out.println("That's right! There's "+wordGroup.size()+" "+guess+"'s.");
        }
    }

    /*
     * This method is used to see if the player has won or run out of guesses.
     * This is represented using an integer [-1,1], where -1 represents a loss,
     * 0 represents neither a win nor loss, and 1 represents a win.
     */
    public int playerStatus(){
        int out;
        if(this.word.getFormat('_').isEmpty()){
            System.out.println("\nYou got it! '"+this.word+"' is the word.");
            out = 1;
        }else if(this.triesLeft <= 0){
            this.word = this.wordSet.randomWord();
            System.out.println("\nYou're out of guesses! '"+this.word+"' was the word.");
            out = -1;
        }else{
            out = 0;
        }
        return out;
    }
}
