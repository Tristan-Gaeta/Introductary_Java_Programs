/**
 * This class contains our set of possible words.
 *
 * @author Tristan Gaeta
 * @version 12-04-2020
 *
 */

import java.util.*;
public class WordSet{
    private Set<Word> wordSet; //the set containing all of our words

    /*
     * Constructor initializes set
     */
    public WordSet(){
        this.wordSet = new HashSet<>();
    }

    /*
     * This method generates subsets of our current word set. These
     * subsets are represented using a HashMap where the key is a set
     * of integers representing the indices where the input character
     * occurs.
     */
    private HashMap<Set<Integer>, Set<Word>> createSubsets(char guess){
        HashMap<Set<Integer>, Set<Word>> subSets = new HashMap<>();
        for(Word w: this.wordSet){
            Set<Integer> form = w.getFormat(guess);
            if(subSets.containsKey(form)){
                subSets.get(form).add(w);
            }
            else{
                Set<Word> list = new HashSet<>();
                list.add(w);
                subSets.put(form,list);
            }
        }
        return subSets;
    }

    /*
     * This method adds a Word to the set
     */
    public boolean add(Word w){
        return this.wordSet.add(w);
    }

    /*
     * This method divides out current set of words into the different
     * subsets, then determines which subset is the largest, and puts
     * the largest subset as our new set.
     */
    public Set<Integer> reduceSet(char guess){
        HashMap<Set<Integer>, Set<Word>> subSets = this.createSubsets(guess);
        int maxSize = -1;
        Map.Entry<Set<Integer>, Set<Word>> largestSubset = null;

        for(Map.Entry<Set<Integer>, Set<Word>> entry: subSets.entrySet()){
            int size = entry.getValue().size();
            if(size > maxSize){
                maxSize = size;
                largestSubset = entry;
            }
        }
        this.wordSet = largestSubset.getValue();
        return largestSubset.getKey();
    }

    /*
     * This method returns a random word from the set. In the game
     * this is used when the player runs out of guesses and we
     * have to reveal what the 'correct' word was
     */
    public Word randomWord(){
        Word[] words = this.wordSet.toArray(new Word[0]);
        int rand = (int) (Math.random()*this.wordSet.size());
        return words[rand];
    }

    /*
     * The String representation of a WordSet object is simply
     * all of the words in the set.
     */
    @Override
    public String toString(){
        return this.wordSet.toString();
    }
}